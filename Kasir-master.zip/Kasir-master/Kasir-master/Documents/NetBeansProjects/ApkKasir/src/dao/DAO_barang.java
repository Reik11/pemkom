package dao;

import config.koneksi;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.M_barang;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import service.S_Barang;

public class DAO_barang implements S_Barang{
    
    private Connection getConnection;
    
    public DAO_barang(){
        getConnection = koneksi.getConnection();
    }

    @Override
    public void tambahData(M_barang mod_bar) {
        PreparedStatement st = null;
        String sql = "INSERT INTO tbl_produk (id_produk, nama_produk, harga_beli, harga_jual, stok, satuan) VALUES (?, ?, ?, ?, ?, ?)";
    try (Connection conn = koneksi.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, mod_bar.getId_produk());
        stmt.setString(2, mod_bar.getNama_produk());
        stmt.setLong(3, mod_bar.getHarga_beli());
        stmt.setLong(4, mod_bar.getHarga_jual());
        stmt.setInt(5, mod_bar.getStok());
        stmt.setString(6, mod_bar.getSatuan());

        stmt.executeUpdate();

        // Menampilkan notifikasi sukses
        JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
    } catch (SQLException ex) {
        // Menampilkan notifikasi kesalahan
        JOptionPane.showMessageDialog(null, "Gagal menambahkan data: " + ex.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
    }
    }

    @Override
    public void perbaruiData(M_barang mod_bar) {
        PreparedStatement st = null;
        String sql = "UPDATE produk SET nama_produk=?, harga_beli=?, harga_jual=?, stok=?, satuan=? WHERE id_produk='" + mod_bar.getId_produk() + "'";
        try{
            st = getConnection.prepareStatement(sql);
            
            st.setString(1, mod_bar.getNama_produk());
            st.setLong(2, mod_bar.getHarga_beli());
            st.setLong(3, mod_bar.getHarga_jual());
            st.setInt(4, mod_bar.getStok());
            st.setString(5, mod_bar.getSatuan());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Perbarui Data Gagal");
            Logger.getLogger(DAO_barang.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DAO_barang.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    @Override
    public void hapusData(M_barang mod_bar) {
        PreparedStatement st = null;
        String sql = "DELETE FROM produk WHERE ID = ?";
        try{
            st = getConnection.prepareStatement(sql);
            
            st.setInt(1, mod_bar.getId_produk());
            
            st.executeUpdate();
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_barang.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_barang.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    @Override
    public M_barang getByid(String id_produk) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public List<M_barang> getDataByID() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public List<M_barang> getData() {
        PreparedStatement st = null;
        List<M_barang> list = new ArrayList<>();
        ResultSet rs = null;
        String sql = "SELECT id_produk, nama_produk, harga_beli, harga_jual, stok, satuan FROM produk";
        try {
            st = getConnection.prepareStatement(sql);
            rs = st.executeQuery();
            while(rs.next()) {
                M_barang mod_bar = new M_barang();
                
                mod_bar.setId_produk(rs.getInt("id_produk"));
                mod_bar.setNama_produk(rs.getString("nama_produk"));
                mod_bar.setHarga_beli(rs.getLong("harga_beli"));
                mod_bar.setHarga_jual(rs.getLong("harga_jual"));
                mod_bar.setStok(rs.getInt("stok"));
                mod_bar.setSatuan(rs.getString("satuan"));
                
                list.add(mod_bar);
            }
          return list;
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_barang.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_barang.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    @Override
    public List<M_barang> pencarian(String id) {
        PreparedStatement st = null;
        List<M_barang> list = new ArrayList<>();
        ResultSet rs = null;
        String sql = "SELECT id_produk, nama_produk, harga_beli, harga_jual, stok, satuan FROM produk WHERE ID LIKE '%" + id + "%' OR nama_produk LIKE '%" + id + "%'";
        try {
            st = getConnection.prepareStatement(sql);
            rs = st.executeQuery();
            while(rs.next()) {
                M_barang mod_bar = new M_barang();
                
                mod_bar.setId_produk(rs.getInt("id_produk"));
                mod_bar.setNama_produk(rs.getString("nama_produk"));
                mod_bar.setHarga_beli(rs.getLong("harga_beli"));
                mod_bar.setHarga_jual(rs.getLong("harga_jual"));
                mod_bar.setStok(rs.getInt("stok"));
                mod_bar.setSatuan(rs.getString("satuan"));
                
                list.add(mod_bar);
            }
          return list;
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_barang.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_barang.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_barang.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    @Override
    public List<M_barang> pencarian2(String id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String nomor() {
        PreparedStatement st = null;
        ResultSet rs = null;
        String urutan = null;
        
        Date now = new Date();
        SimpleDateFormat tanggal = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat noformat = new SimpleDateFormat("yyMM");
        String tgl = tanggal.format(now);
        String no = noformat.format(now);
        
        String sql = "SELECT RIGHT(ID, 3) AS Nomor " +
                     "FROM produk " +
                     "WHERE iID LIKE '" + no + "%' " +
                     "ORDER BY ID DESC " +
                     "LIMIT 1";
        
        try {
            st = getConnection.prepareStatement(sql);
            rs = st.executeQuery();
            
            if (rs.next()) {
                int nomor = Integer.parseInt(rs.getString("Nomor"));
                nomor++;
                urutan = no + String.format("%03d", nomor);
            } else {
                urutan = no + "001";
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DAO_barang.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException ex) {
                    java.util.logging.Logger.getLogger(DAO_barang.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        return urutan;
    }

    @Override
    public String nomor2() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}